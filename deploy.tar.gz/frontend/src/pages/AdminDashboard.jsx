import React, { useEffect, useState, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getAdminDashboardData } from '../store/reportSlice';
import { Link, useNavigate } from 'react-router-dom';
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  PointElement,
  LineElement,
  Filler
} from 'chart.js';
import { Doughnut, Bar, Line } from 'react-chartjs-2';

// Register ChartJS components
ChartJS.register(
  ArcElement,
  Tooltip,
  Legend,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  PointElement,
  LineElement,
  Filler
);

const AdminDashboard = () => {
  const dispatch = useDispatch();
  const { adminDashboardData, loading, error } = useSelector((state) => state.reports);
  const { user } = useSelector((state) => state.auth);
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');
  const [timeContext, setTimeContext] = useState('today');
  const [lastUpdated, setLastUpdated] = useState(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const fetchData = useCallback(async () => {
    setIsRefreshing(true);
    await dispatch(getAdminDashboardData(timeContext));
    setLastUpdated(new Date());
    setIsRefreshing(false);
  }, [dispatch, timeContext]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Auto-refresh every 5 minutes
  useEffect(() => {
    const interval = setInterval(() => {
      fetchData();
    }, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, [fetchData]);

  // Enhanced dashboard data with admin-specific metrics
  const adminDashboard = adminDashboardData?.dashboard || {
    projects: { totalProjects: 0, totalProjectsInProgress: 0, totalProjectsCompleted: 0, totalProjectsDelayed: 0 },
    tasks: { totalTasksCompleted: 0, totalTasksOverdue: 0, tasksDueToday: 0 },
    attendance: { totalPresent: 0, presentToday: 0, averageHours: 0 },
    staff: { totalStaffCount: 0, activeStaffCount: 0 },
    productivity: { productivityPercentage: 0, totalOvertimeHours: 0 },
    revenue: { totalRevenue: 0, completedProjectsRevenue: 0, pendingRevenue: 0 },
    delayedProjects: []
  };

  // Chart data for admin dashboard
  const projectStatusData = {
    labels: ['Completed', 'In Progress', 'Delayed', 'Planning', 'On Hold'],
    datasets: [
      {
        data: [
          adminDashboard.projects.totalProjectsCompleted,
          adminDashboard.projects.totalProjectsInProgress,
          adminDashboard.projects.totalProjectsDelayed,
          adminDashboard.projects.totalProjects - adminDashboard.projects.totalProjectsCompleted - adminDashboard.projects.totalProjectsInProgress - adminDashboard.projects.totalProjectsDelayed,
          0 // On Hold
        ],
        backgroundColor: [
          '#4CAF50', // Green for completed
          '#700606', // Burgundy for in progress
          '#FF9800', // Orange for delayed
          '#9C27B0', // Purple for planning
          '#607D8B'  // Grey for on hold
        ],
        hoverBackgroundColor: [
          '#66BB6A',
          '#900808',
          '#FFB74D',
          '#AB47BC',
          '#78909C'
        ]
      }
    ]
  };

  const taskStatusData = {
    labels: ['Completed', 'Overdue', 'Due Today', 'In Progress'],
    datasets: [
      {
        label: 'Tasks',
        data: [
          adminDashboard.tasks.totalTasksCompleted,
          adminDashboard.tasks.totalTasksOverdue,
          adminDashboard.tasks.tasksDueToday,
          adminDashboard.tasks.tasksInProgress || 0
        ],
        backgroundColor: [
          '#4CAF50',
          '#F44336',
          '#FFC107',
          '#700606'
        ]
      }
    ]
  };

  const productivityData = {
    labels: ['Productivity %', 'Overtime Hours', 'Staff Utilization'],
    datasets: [
      {
        label: 'Metrics',
        data: [
          adminDashboard.productivity.productivityPercentage,
          adminDashboard.productivity.totalOvertimeHours,
          adminDashboard.staff.totalStaffCount > 0 ?
            Math.round((adminDashboard.staff.activeStaffCount / adminDashboard.staff.totalStaffCount) * 100) : 0
        ],
        backgroundColor: [
          '#4CAF50',
          '#FF9800',
          '#700606'
        ]
      }
    ]
  };

  const revenueData = {
    labels: ['Total Revenue', 'Completed Revenue', 'Pending Revenue'],
    datasets: [
      {
        label: 'Revenue (AED)',
        data: [
          adminDashboard.revenue.totalRevenue,
          adminDashboard.revenue.completedProjectsRevenue,
          adminDashboard.revenue.pendingRevenue
        ],
        backgroundColor: [
          '#4CAF50',
          '#700606',
          '#FFC107'
        ]
      }
    ]
  };

  // Risk assessment data
  const riskData = {
    labels: adminDashboard.delayedProjects.slice(0, 5).map(p => p.name),
    datasets: [
      {
        label: 'Days Delayed',
        data: adminDashboard.delayedProjects.slice(0, 5).map(p => p.daysDelayed),
        backgroundColor: '#F44336',
        borderColor: '#D32F2F',
        borderWidth: 1
      }
    ]
  };

  // Insight texts
  const projectInsight = `${adminDashboard.projects.totalProjectsDelayed} project${adminDashboard.projects.totalProjectsDelayed !== 1 ? 's' : ''} ${adminDashboard.projects.totalProjectsDelayed === 1 ? 'is' : 'are'} at risk due to delayed tasks.`;
  const taskInsight = `${adminDashboard.tasks.totalTasksOverdue} task${adminDashboard.tasks.totalTasksOverdue !== 1 ? 's' : ''} overdue, ${adminDashboard.tasks.tasksDueToday} due today.`;
  const productivityInsight = `Current productivity at ${adminDashboard.productivity.productivityPercentage}%, with ${adminDashboard.productivity.totalOvertimeHours} overtime hours logged.`;
  const revenueInsight = `Total revenue of AED ${adminDashboard.revenue.totalRevenue.toLocaleString()}, with AED ${adminDashboard.revenue.pendingRevenue.toLocaleString()} still pending.`;

  // Top insights data
  const projectInsights = adminDashboard.delayedProjects.slice(0, 3).map(p => ({
    name: p.name,
    value: `${p.daysDelayed} days delayed`,
    daysDelayed: p.daysDelayed,
    link: `/projects/${p.id}`
  }));
  const taskInsights = [
    { name: 'Overdue Tasks', value: adminDashboard.tasks.totalTasksOverdue, link: '/tasks' },
    { name: 'Due Today', value: adminDashboard.tasks.tasksDueToday, link: '/tasks' },
    { name: 'In Progress', value: adminDashboard.tasks.tasksInProgress || 0, link: '/tasks' },
    { name: 'Completed', value: adminDashboard.tasks.totalTasksCompleted, link: '/tasks' }
  ].filter(item => item.value > 0).slice(0, 3);
  const productivityInsights = [
    {
      name: 'Productivity %',
      value: `${adminDashboard.productivity.productivityPercentage}%`,
      rawValue: adminDashboard.productivity.productivityPercentage,
      link: '/tasks',
      type: 'percentage'
    },
    {
      name: 'Overtime Hours',
      value: adminDashboard.productivity.totalOvertimeHours,
      rawValue: adminDashboard.productivity.totalOvertimeHours,
      link: '/attendance',
      type: 'hours'
    },
    {
      name: 'Staff Utilization',
      value: `${adminDashboard.staff.totalStaffCount > 0 ? Math.round((adminDashboard.staff.activeStaffCount / adminDashboard.staff.totalStaffCount) * 100) : 0}%`,
      rawValue: adminDashboard.staff.totalStaffCount > 0 ? Math.round((adminDashboard.staff.activeStaffCount / adminDashboard.staff.totalStaffCount) * 100) : 0,
      link: '/admin/users',
      type: 'utilization'
    }
  ].slice(0, 3);
  const revenueInsights = [
    {
      name: 'Total Revenue',
      value: `AED ${adminDashboard.revenue.totalRevenue.toLocaleString()}`,
      link: '/projects',
      type: 'total'
    },
    {
      name: 'Completed Revenue',
      value: `AED ${adminDashboard.revenue.completedProjectsRevenue.toLocaleString()}`,
      link: '/projects?status=completed',
      type: 'completed'
    },
    {
      name: 'Pending Revenue',
      value: `AED ${adminDashboard.revenue.pendingRevenue.toLocaleString()}`,
      link: '/projects?filter=pending',
      type: 'pending'
    }
  ].slice(0, 3);

  // Loading state
  if (loading && !adminDashboardData) {
    return (
      <div className="space-y-6 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen p-6">
        <div className="bg-white/80 backdrop-blur-sm rounded-xl shadow-lg border border-white/20 p-6">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2 mb-6"></div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-32 bg-gray-200 rounded-xl"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="space-y-6 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen p-6">
        <div className="bg-white/80 backdrop-blur-sm rounded-xl shadow-lg border border-white/20 p-6">
          <div className="text-center py-12">
            <div className="bg-red-100 p-4 rounded-full w-fit mx-auto mb-4">
              <svg className="w-8 h-8 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Failed to load dashboard data</h3>
            <p className="text-gray-600 mb-6">{error}</p>
            <button
              onClick={fetchData}
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-medium transition-colors"
            >
              Try Again
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 bg-gradient-to-br from-slate-50 to-[#700606]/5 min-h-screen p-6">
      {/* Admin Header */}
      <div className="bg-gradient-to-r from-[#700606] to-[#a04040] rounded-xl p-6 mb-6 text-white">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-4xl font-bold mb-2">Admin Dashboard</h1>
            <p className="text-white/80 text-sm">Enterprise Management Console</p>
          </div>
          <div className="flex items-center space-x-6">
            <div className="text-right">
              <p className="text-sm text-white">Welcome, {user?.fullName}</p>
              <p className="text-xs text-white/80">Administrator</p>
              {lastUpdated && (
                <p className="text-xs text-white/70">Last updated: {lastUpdated.toLocaleTimeString()}</p>
              )}
            </div>
            <button
              onClick={fetchData}
              disabled={isRefreshing}
              className="p-2 bg-[#700606]/20 hover:bg-[#700606]/30 rounded-full transition-all duration-300 disabled:opacity-50"
              title="Refresh Data"
            >
              <svg className={`w-5 h-5 text-[#700606] ${isRefreshing ? 'animate-spin' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
            </button>
            <div className="flex space-x-2">
              <button
                className={`px-4 py-2 text-sm font-medium rounded-lg transition-all duration-300 ${activeTab === 'overview'
                  ? 'bg-gradient-to-r from-[#700606] to-[#900808] text-white shadow-lg'
                  : 'bg-white text-gray-700 hover:bg-[#700606]/10 shadow-sm'
                  }`}
                onClick={() => setActiveTab('overview')}
              >
                Overview
              </button>
              <button
                className={`px-4 py-2 text-sm font-medium rounded-lg transition-all duration-300 ${activeTab === 'analytics'
                  ? 'bg-gradient-to-r from-[#700606] to-[#900808] text-white shadow-lg'
                  : 'bg-white text-gray-700 hover:bg-[#700606]/10 shadow-sm'
                  }`}
                onClick={() => setActiveTab('analytics')}
              >
                Analytics
              </button>

            </div>
          </div>
        </div>
      </div>

      {/* Time Context Toggle */}
      <div className="bg-white/60 backdrop-blur-sm rounded-lg shadow-sm border border-white/20 p-4">
        <div className="flex items-center justify-center space-x-4">
          <span className="text-sm font-medium text-gray-700">Time Context:</span>
          <div className="flex bg-gray-100 rounded-lg p-1">
            <button
              className={`px-4 py-2 text-sm font-medium rounded-md transition-all duration-300 ${timeContext === 'today'
                ? 'bg-white text-blue-600 shadow-sm'
                : 'text-gray-600 hover:text-gray-800'
                }`}
              onClick={() => setTimeContext('today')}
            >
              Today
            </button>
            <button
              className={`px-4 py-2 text-sm font-medium rounded-md transition-all duration-300 ${timeContext === 'week'
                ? 'bg-white text-blue-600 shadow-sm'
                : 'text-gray-600 hover:text-gray-800'
                }`}
              onClick={() => setTimeContext('week')}
            >
              This Week
            </button>
            <button
              className={`px-4 py-2 text-sm font-medium rounded-md transition-all duration-300 ${timeContext === 'month'
                ? 'bg-white text-blue-600 shadow-sm'
                : 'text-gray-600 hover:text-gray-800'
                }`}
              onClick={() => setTimeContext('month')}
            >
              This Month
            </button>
          </div>
        </div>
      </div>

      {/* Action Required Section */}
      <div className="bg-gradient-to-r from-orange-50 to-red-50 p-6 rounded-xl shadow-lg border border-orange-200/50 backdrop-blur-sm">
        <h2 className="text-2xl font-bold text-gray-900 mb-2 flex items-center">
          <div className="bg-orange-100 p-2 rounded-full mr-3">
            <svg className="w-6 h-6 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
            </svg>
          </div>
          Action Required
        </h2>
        <p className="text-sm text-gray-600 mb-6">Critical items requiring immediate attention</p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Delayed Projects */}
          <Link to="/projects?filter=delayed" className="bg-white/80 p-6 rounded-xl border border-red-200/50 hover:bg-red-50 hover:shadow-xl hover:scale-105 transition-all duration-300 cursor-pointer backdrop-blur-sm">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <p className="text-sm text-red-700 font-semibold uppercase tracking-wide">Delayed Projects</p>
                <p className="text-3xl font-bold text-red-800 mt-2">{adminDashboard.projects.totalProjectsDelayed}</p>
                {adminDashboard.projects.totalProjectsDelayed === 0 && <p className="text-xs text-red-600 mt-2">All projects on track</p>}
                <div className="mt-2 flex items-center">
                  <span className="text-xs text-red-600 bg-red-100 px-2 py-1 rounded-full">Critical</span>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="text-right">
                  <svg className="w-8 h-8 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <svg className="w-5 h-5 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </div>
            </div>
          </Link>

          {/* At-Risk Projects */}
          <Link to="/projects?filter=at-risk" className="bg-white/80 p-6 rounded-xl border border-yellow-200/50 hover:bg-yellow-50 hover:shadow-xl hover:scale-105 transition-all duration-300 cursor-pointer backdrop-blur-sm">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <p className="text-sm text-yellow-700 font-semibold uppercase tracking-wide">At-Risk Projects</p>
                <p className="text-3xl font-bold text-yellow-800 mt-2">{adminDashboard.projects.totalProjectsAtRisk || 0}</p>
                {adminDashboard.projects.totalProjectsAtRisk === 0 ? (
                  <p className="text-xs text-yellow-600 mt-2">No active projects approaching deadline</p>
                ) : (
                  <p className="text-xs text-yellow-600 mt-2">Due within 7 days</p>
                )}
                <div className="mt-2 flex items-center">
                  <span className="text-xs text-yellow-600 bg-yellow-100 px-2 py-1 rounded-full">Monitor</span>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="text-right">
                  <svg className="w-8 h-8 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
                  </svg>
                </div>
                <svg className="w-5 h-5 text-yellow-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </div>
            </div>
          </Link>

          {/* Overdue Tasks */}
          <Link to="/tasks?filter=overdue" className="bg-white/80 p-6 rounded-xl border border-orange-200/50 hover:bg-orange-50 hover:shadow-xl hover:scale-105 transition-all duration-300 cursor-pointer backdrop-blur-sm">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <p className="text-sm text-orange-700 font-semibold uppercase tracking-wide">Overdue Tasks</p>
                <p className="text-3xl font-bold text-orange-800 mt-2">{adminDashboard.tasks.totalTasksOverdue}</p>
                {adminDashboard.tasks.totalTasksOverdue === 0 && <p className="text-xs text-orange-600 mt-2">No blockers</p>}
                <div className="mt-2 flex items-center">
                  <span className="text-xs text-orange-600 bg-orange-100 px-2 py-1 rounded-full">Urgent</span>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="text-right">
                  <svg className="w-8 h-8 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <svg className="w-5 h-5 text-orange-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </div>
            </div>
          </Link>
        </div>
      </div>



      {/* Summary Cards - Enhanced for Admin */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Project Metrics */}
        <div className="bg-white/80 backdrop-blur-sm p-6 rounded-xl shadow-lg border border-white/20 hover:shadow-xl hover:scale-105 transition-all duration-300">
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <p className="text-sm font-medium text-gray-500 uppercase tracking-wide">Total Projects</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{adminDashboard.projects.totalProjects}</p>
              <p className="text-xs text-gray-500 mt-3 flex items-center space-x-4">
                <span className="flex items-center">
                  <div className="w-2 h-2 bg-green-500 rounded-full mr-1"></div>
                  {adminDashboard.projects.totalProjectsCompleted} Completed
                </span>
                <span className="flex items-center">
                  <div className="w-2 h-2 bg-red-500 rounded-full mr-1"></div>
                  {adminDashboard.projects.totalProjectsDelayed} Delayed
                </span>
              </p>
            </div>
            <div className="bg-gradient-to-br from-[#700606]/20 to-[#700606]/30 p-3 rounded-xl">
              <svg className="w-7 h-7 text-[#700606]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
          </div>
        </div>

        {/* Staff Metrics */}
        <div className="bg-white/80 backdrop-blur-sm p-6 rounded-xl shadow-lg border border-white/20 hover:shadow-xl hover:scale-105 transition-all duration-300">
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <p className="text-sm font-medium text-gray-500 uppercase tracking-wide">Total Staff</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{adminDashboard.staff.totalStaffCount}</p>
              <p className="text-xs text-gray-500 mt-3 flex items-center space-x-4">
                <span className="flex items-center">
                  <div className="w-2 h-2 bg-green-500 rounded-full mr-1"></div>
                  {adminDashboard.staff.activeStaffCount} Active
                </span>
                <span className="flex items-center">
                  <div className="w-2 h-2 bg-gray-500 rounded-full mr-1"></div>
                  {adminDashboard.staff.totalStaffCount - adminDashboard.staff.activeStaffCount} Inactive
                </span>
              </p>
            </div>
            <div className="bg-gradient-to-br from-green-100 to-green-200 p-3 rounded-xl">
              <svg className="w-7 h-7 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
              </svg>
            </div>
          </div>
        </div>

        {/* Task Metrics */}
        <div className="bg-white/80 backdrop-blur-sm p-6 rounded-xl shadow-lg border border-white/20 hover:shadow-xl hover:scale-105 transition-all duration-300">
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <p className="text-sm font-medium text-gray-500 uppercase tracking-wide">Task Status</p>
              <p className="text-3xl font-bold text-green-600 mt-2">{adminDashboard.tasks.totalTasksCompleted}</p>
              <p className="text-xs text-gray-500 mt-3 flex items-center space-x-4">
                <span className="flex items-center">
                  <div className="w-2 h-2 bg-red-500 rounded-full mr-1"></div>
                  {adminDashboard.tasks.totalTasksOverdue} Overdue
                </span>
                <span className="flex items-center">
                  <div className="w-2 h-2 bg-yellow-500 rounded-full mr-1"></div>
                  {adminDashboard.tasks.tasksDueToday} Due Today
                </span>
              </p>
            </div>
            <div className="bg-gradient-to-br from-yellow-100 to-yellow-200 p-3 rounded-xl">
              <svg className="w-7 h-7 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
          </div>
        </div>

        {/* Productivity Metrics */}
        <div className="bg-white/80 backdrop-blur-sm p-6 rounded-xl shadow-lg border border-white/20 hover:shadow-xl hover:scale-105 transition-all duration-300">
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <p className="text-sm font-medium text-gray-500 uppercase tracking-wide">Productivity</p>
              <p className="text-3xl font-bold text-[#700606] mt-2">{adminDashboard.productivity.productivityPercentage}%</p>
              <p className="text-xs text-gray-500 mt-3 flex items-center">
                <div className="w-2 h-2 bg-purple-500 rounded-full mr-1"></div>
                {adminDashboard.productivity.totalOvertimeHours} OT Hours
              </p>
            </div>
            <div className="bg-gradient-to-br from-purple-100 to-purple-200 p-3 rounded-xl">
              <svg className="w-7 h-7 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
          </div>
        </div>
      </div>

      {/* Revenue Metrics */}
      <div className="bg-white/80 backdrop-blur-sm p-6 rounded-xl shadow-lg border border-white/20">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold text-gray-900 flex items-center">
            <div className="bg-green-100 p-2 rounded-full mr-3">
              <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
              </svg>
            </div>
            Revenue Overview
          </h3>
          <span className="text-sm text-gray-500 bg-gray-100 px-3 py-1 rounded-full">Company Financial Health</span>
        </div>
        <div className="grid grid-cols-3 gap-6">
          <div className="text-center bg-gradient-to-br from-green-50 to-green-100 p-4 rounded-xl border border-green-200/50">
            <p className="text-sm font-medium text-gray-600 mb-2">Total Revenue</p>
            <p className="text-2xl font-bold text-green-600">AED {adminDashboard.revenue.totalRevenue.toLocaleString()}</p>
            <div className="mt-2 w-full bg-green-200 rounded-full h-2">
              <div className="bg-green-500 h-2 rounded-full" style={{ width: '100%' }}></div>
            </div>
          </div>
          <div className="text-center bg-gradient-to-br from-blue-50 to-blue-100 p-4 rounded-xl border border-blue-200/50">
            <p className="text-sm font-medium text-gray-600 mb-2">Completed Revenue</p>
            <p className="text-2xl font-bold text-blue-600">AED {adminDashboard.revenue.completedProjectsRevenue.toLocaleString()}</p>
            <div className="mt-2 w-full bg-blue-200 rounded-full h-2">
              <div className="bg-blue-500 h-2 rounded-full" style={{ width: `${adminDashboard.revenue.totalRevenue > 0 ? (adminDashboard.revenue.completedProjectsRevenue / adminDashboard.revenue.totalRevenue * 100) : 0}%` }}></div>
            </div>
          </div>
          <div className="text-center bg-gradient-to-br from-yellow-50 to-yellow-100 p-4 rounded-xl border border-yellow-200/50">
            <p className="text-sm font-medium text-gray-600 mb-2">Pending Revenue</p>
            <p className="text-2xl font-bold text-yellow-600">AED {adminDashboard.revenue.pendingRevenue.toLocaleString()}</p>
            <div className="mt-2 w-full bg-yellow-200 rounded-full h-2">
              <div className="bg-yellow-500 h-2 rounded-full" style={{ width: `${adminDashboard.revenue.totalRevenue > 0 ? (adminDashboard.revenue.pendingRevenue / adminDashboard.revenue.totalRevenue * 100) : 0}%` }}></div>
            </div>
          </div>
        </div>
      </div>


      {/* Charts Section */}
      {activeTab === 'overview' && (
        <>
          {/* Project Status Chart */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-white/80 backdrop-blur-sm p-6 rounded-xl shadow-lg border border-white/20">
              <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
                <div className="bg-blue-100 p-2 rounded-full mr-3">
                  <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                </div>
                Project Status Distribution
              </h3>
              <p className="text-sm text-gray-600 mb-6">{projectInsight}</p>
              <div className="h-64 mb-6">
                <Doughnut data={projectStatusData} options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  onClick: (event, elements) => {
                    if (elements.length > 0) {
                      const index = elements[0].index;
                      const label = projectStatusData.labels[index].toLowerCase().replace(' ', '-');
                      navigate(`/projects?status=${label}`);
                    }
                  },
                  onHover: (event, chartElement) => {
                    event.native.target.style.cursor = chartElement[0] ? 'pointer' : 'default';
                  },
                  plugins: {
                    legend: {
                      position: 'bottom',
                      labels: {
                        padding: 20,
                        usePointStyle: true
                      }
                    }
                  }
                }} />
              </div>
              <div className="bg-gradient-to-r from-gray-50 to-gray-100 p-4 rounded-xl border border-gray-200/50">
                <h4 className="text-sm font-semibold text-gray-900 mb-3 flex items-center">
                  <svg className="w-4 h-4 text-blue-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Top Insights
                </h4>
                <ul className="space-y-2">
                  {projectInsights.map((item, index) => (
                    <li key={index}>
                      <Link to={item.link} className="text-sm text-gray-700 hover:text-blue-800 block p-2 rounded-lg hover:bg-blue-50 transition-all duration-200 border border-transparent hover:border-blue-100 shadow-sm hover:shadow-md bg-white">
                        <div className="flex justify-between items-center">
                          <span className="font-semibold">{item.name}</span>
                          <span className={`text-xs px-2 py-1 rounded-full font-bold ${item.daysDelayed >= 7 ? 'bg-red-100 text-red-700' :
                            item.daysDelayed >= 3 ? 'bg-orange-100 text-orange-700' :
                              'bg-yellow-100 text-yellow-700'
                            }`}>
                            {item.value}
                          </span>
                        </div>
                      </Link>
                    </li>
                  ))}
                </ul>
                {projectInsights.length === 0 && <p className="text-sm text-gray-500 mt-2">No delayed projects at this time.</p>}
              </div>
            </div>

            <div className="bg-white/80 backdrop-blur-sm p-6 rounded-xl shadow-lg border border-white/20">
              <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
                <div className="bg-green-100 p-2 rounded-full mr-3">
                  <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                Task Status Overview
              </h3>
              <p className="text-sm text-gray-600 mb-6">{taskInsight}</p>
              <div className="h-64 mb-6">
                <Bar data={taskStatusData} options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      display: false
                    }
                  },
                  scales: {
                    y: {
                      beginAtZero: true,
                      grid: {
                        color: 'rgba(0,0,0,0.05)'
                      }
                    },
                    x: {
                      grid: {
                        display: false
                      }
                    }
                  }
                }} />
              </div>
              <div className="bg-gradient-to-r from-gray-50 to-gray-100 p-4 rounded-xl border border-gray-200/50">
                <h4 className="text-sm font-semibold text-gray-900 mb-3 flex items-center">
                  <svg className="w-4 h-4 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Top Insights
                </h4>
                <ul className="space-y-2">
                  {taskInsights.map((item, index) => (
                    <li key={index}>
                      <Link to={item.link} className="text-sm text-blue-600 hover:text-blue-800 block p-2 rounded-lg hover:bg-blue-50 transition-colors">
                        <span className="font-medium">{item.name}:</span> {item.value}
                      </Link>
                    </li>
                  ))}
                </ul>
                {taskInsights.length === 0 && <p className="text-sm text-gray-500 mt-2">No task insights available.</p>}
              </div>
            </div>
          </div>

          {/* Productivity and Revenue Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-white/80 backdrop-blur-sm p-6 rounded-xl shadow-lg border border-white/20">
              <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
                <div className="bg-purple-100 p-2 rounded-full mr-3">
                  <svg className="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
                {timeContext === 'today' ? 'Today\'s' : timeContext === 'week' ? 'This Week\'s' : 'This Month\'s'} Productivity Metrics
              </h3>
              <p className="text-sm text-gray-600 mb-6">{productivityInsight}</p>
              <div className="h-64 mb-6">
                <Bar data={productivityData} options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      display: false
                    }
                  },
                  scales: {
                    y: {
                      beginAtZero: true,
                      grid: {
                        color: 'rgba(0,0,0,0.05)'
                      }
                    },
                    x: {
                      grid: {
                        display: false
                      }
                    }
                  }
                }} />
              </div>
              <div className="bg-gradient-to-r from-gray-50 to-gray-100 p-4 rounded-xl border border-gray-200/50">
                <h4 className="text-sm font-semibold text-gray-900 mb-3 flex items-center">
                  <svg className="w-4 h-4 text-purple-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Top Insights
                </h4>
                <ul className="space-y-2">
                  {productivityInsights.map((item, index) => (
                    <li key={index}>
                      <Link to={item.link} className="text-sm text-gray-700 hover:text-blue-800 block p-2 rounded-lg hover:bg-blue-50 transition-all duration-200 border border-transparent hover:border-blue-100 shadow-sm hover:shadow-md bg-white">
                        <div className="flex justify-between items-center">
                          <span className="font-semibold">{item.name}</span>
                          <span className={`text-xs px-2 py-1 rounded-full font-bold ${item.type === 'percentage'
                            ? (item.rawValue >= 80 ? 'bg-green-100 text-green-700' : item.rawValue >= 60 ? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700')
                            : item.type === 'hours'
                              ? (item.rawValue === 0 ? 'bg-green-100 text-green-700' : item.rawValue > 20 ? 'bg-red-100 text-red-700' : 'bg-orange-100 text-orange-700')
                              : (item.rawValue >= 90 ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700')
                            }`}>
                            {item.value}
                          </span>
                        </div>
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="bg-white/80 backdrop-blur-sm p-6 rounded-xl shadow-lg border border-white/20">
              <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
                <div className="bg-green-100 p-2 rounded-full mr-3">
                  <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
                  </svg>
                </div>
                {timeContext === 'today' ? 'Today\'s' : timeContext === 'week' ? 'This Week\'s' : 'This Month\'s'} Revenue Distribution
              </h3>
              <p className="text-sm text-gray-600 mb-6">{revenueInsight}</p>
              <div className="h-64 mb-6">
                <Doughnut data={revenueData} options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  onClick: (event, elements) => {
                    if (elements.length > 0) {
                      const index = elements[0].index;
                      const label = index === 0 ? 'completed' : index === 1 ? 'in-progress' : 'delayed';
                      navigate(`/projects?status=${label}`);
                    }
                  },
                  onHover: (event, chartElement) => {
                    event.native.target.style.cursor = chartElement[0] ? 'pointer' : 'default';
                  },
                  plugins: {
                    legend: {
                      position: 'bottom',
                      labels: {
                        padding: 20,
                        usePointStyle: true
                      }
                    }
                  }
                }} />
              </div>
              <div className="bg-gradient-to-r from-gray-50 to-gray-100 p-4 rounded-xl border border-gray-200/50">
                <h4 className="text-sm font-semibold text-gray-900 mb-3 flex items-center">
                  <svg className="w-4 h-4 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Top Insights
                </h4>
                <ul className="space-y-2">
                  {revenueInsights.map((item, index) => (
                    <li key={index}>
                      <Link to={item.link} className="text-sm text-gray-700 hover:text-blue-800 block p-2 rounded-lg hover:bg-blue-50 transition-all duration-200 border border-transparent hover:border-blue-100 shadow-sm hover:shadow-md bg-white">
                        <div className="flex justify-between items-center">
                          <span className="font-semibold">{item.name}</span>
                          <span className={`text-xs px-2 py-1 rounded-full font-bold ${item.type === 'total' ? 'bg-blue-100 text-blue-700' :
                            item.type === 'completed' ? 'bg-green-100 text-green-700' :
                              'bg-yellow-100 text-yellow-700'
                            }`}>
                            {item.value}
                          </span>
                        </div>
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Risk Assessment Section */}
      {activeTab === 'analytics' && (
        <div className="bg-white/80 backdrop-blur-sm p-6 rounded-xl shadow-lg border border-white/20">
          <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
            <div className="bg-red-100 p-2 rounded-full mr-3">
              <svg className="w-5 h-5 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
              </svg>
            </div>
            Project Risk Assessment
          </h3>
          <p className="text-sm text-gray-600 mb-6">
            Top {adminDashboard.delayedProjects.length} delayed projects requiring immediate attention
          </p>
          <div className="h-64 mb-8">
            <Bar data={riskData} options={{
              responsive: true,
              maintainAspectRatio: false,
              plugins: {
                legend: {
                  display: true,
                  position: 'top',
                  labels: {
                    usePointStyle: true,
                    padding: 20
                  }
                }
              },
              scales: {
                y: {
                  beginAtZero: true,
                  grid: {
                    color: 'rgba(0,0,0,0.05)'
                  }
                },
                x: {
                  grid: {
                    display: false
                  }
                }
              }
            }} />
          </div>

          {/* Delayed Projects Table */}
          <div className="bg-gradient-to-r from-gray-50 to-gray-100 rounded-xl p-6 border border-gray-200/50">
            <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <svg className="w-5 h-5 text-red-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              Delayed Projects Details
            </h4>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-white/50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Project</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Status</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Days Delayed</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Impact</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Revenue at Risk</th>
                  </tr>
                </thead>
                <tbody className="bg-white/30 divide-y divide-gray-200">
                  {adminDashboard.delayedProjects.slice(0, 5).map((project, index) => (
                    <tr key={index} className="hover:bg-white/50 transition-colors">
                      <td className="px-4 py-3 whitespace-nowrap">
                        <div className="text-sm font-semibold text-gray-900">{project.name}</div>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <span className="px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800 border border-red-200">
                          {project.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-600 font-medium">
                        {project.daysDelayed} days
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-600">
                        {project.impact}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm font-bold text-red-600">
                        ${project.potentialRevenueLoss?.toLocaleString() || 'N/A'}
                      </td>
                    </tr>
                  ))}
                  {adminDashboard.delayedProjects.length === 0 && (
                    <tr>
                      <td colSpan="5" className="px-4 py-6 text-center text-sm text-gray-500">
                        <div className="flex items-center justify-center">
                          <svg className="w-5 h-5 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                          No delayed projects found
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}


    </div>
  );
};

export default AdminDashboard;